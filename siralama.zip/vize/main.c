#include <stdio.h>
#include <stdlib.h>
struct degerler{
    char customers[20];
    char yasgrup;
    char isim[20];
};
#define SIZE 10
#define SIZE2 14
FILE *dosya;
int countN, countS;
int BaslangicElder,BaslangicAdult,BaslangicChild, SonuncuElder,SonuncuAdult,SonuncuChild;
char elderSirasi[SIZE][SIZE2] , childSirasi[SIZE][SIZE2], adultSirasi[SIZE][SIZE2];
int kuyrukSayi=10;
int servisMax=100;
int servisSayisi;
char outputIsim[200][20];
char outputkod[200];

void oku(struct degerler toplu[]){
 int i=0,j=0;
 if((dosya =fopen("input.txt","a+"))!= NULL) {
    while(!feof(dosya)) {

          fscanf(dosya, "%s %c %s\n" ,&toplu[i].customers,&toplu[i].yasgrup,&toplu[i].isim);
          printf("%s \t%c \t%s\n" ,toplu[i].customers,toplu[i].yasgrup,toplu[i].isim);
          i++;
        }

    }
    for(j=0; j<kelimeHesapla(); j++){
        if(!strcmp(toplu[j].customers, "NewCustomer")){
           countN++;
        }
        else{
            countS++;
        }
    }
     fclose(dosya);
}

 void Ayirma(struct degerler toplu[]){
   int i , j =0,k=0;

    for(i=0 ; i<kelimeHesapla(); i++){

        if(toplu[i].yasgrup== 'C'){

           if(!strcmp(toplu[i].customers, "NewCustomer")){
            ChildEkleme(toplu,i);

           }
           else if(!strcmp(toplu[i].customers, "ServeCustomers")){
                ChildSilme(toplu,i);
           }
        }
         else if(toplu[i].yasgrup== 'A'){

           if(!strcmp(toplu[i].customers, "NewCustomer")){
                AdultEkleme(toplu,i);
           }
            else if(!strcmp(toplu[i].customers, "ServeCustomers")){
                    AdultSilme(toplu,i);
           }
        }
         else if(toplu[i].yasgrup== 'E'){

           if(!strcmp(toplu[i].customers, "NewCustomer")){
                  ElderEkleme(toplu,i);
           }
            else if(!strcmp(toplu[i].customers, "ServeCustomers")){
                    ElderSilme(toplu,i);

           }
        }

    }

}
void ChildEkleme(struct degerler toplu[],int i){
     if(BaslangicChild == SonuncuChild) {
        //printf("S�ra bo�");
    }
    if(SonuncuChild-BaslangicChild<kuyrukSayi){
     if(SonuncuChild >= 10) {
     	int i ;
            for( i = 0 ;i<SonuncuChild-BaslangicChild ;i++) {
                childSirasi[i][20] = childSirasi[BaslangicChild+i][20];
            }
             SonuncuChild-=BaslangicChild;
             BaslangicChild =0;
    }
    strcpy(childSirasi[SonuncuChild++],toplu[i].isim);
     printf("\n %s Eklendi\n",toplu[i].isim);
      printf("\n Childekle: %d %d\n",BaslangicChild,SonuncuChild);
    }
    else{
        printf("kuyruktaki maksimum 10 kisidir.Bu gruptan birine hizmet edilmeden ekleme.\n");
    }
}
void AdultEkleme(struct degerler toplu[],int i){
     if(BaslangicAdult == SonuncuAdult) {
        //printf("S�ra bo�");
    }
     if(SonuncuAdult-BaslangicAdult<kuyrukSayi){
     if(SonuncuAdult >= 10) {
     	int i;
            for( i = 0 ;i<SonuncuAdult-BaslangicAdult ;i++) {
                adultSirasi[i][20] = adultSirasi[BaslangicAdult+i][20];
            }
             SonuncuAdult-=BaslangicAdult;
             BaslangicAdult =0;
    }
    strcpy(adultSirasi[SonuncuAdult++],toplu[i].isim);
     printf("\n%s Eklendi\n",toplu[i].isim);
      printf("\n Adoekle : %d %d\n",BaslangicAdult,SonuncuAdult);
     }
     else{
        printf("kuyruktaki maksimum 10 kisidir.Bu gruptan birine hizmet edilmeden ekleme.\n");
     }
}

void ElderEkleme(struct degerler toplu[],int i){
    if(BaslangicElder == SonuncuElder) {
        //printf("S�ra bo�");
    }
      if(SonuncuElder-BaslangicElder<kuyrukSayi){
     if(SonuncuElder >= 10) {
     	int i ;
            for(i = 0 ;i<SonuncuElder-BaslangicElder ;i++) {
                elderSirasi[i][20] = elderSirasi[BaslangicElder+i][20];
            }
             SonuncuElder-=BaslangicElder;
             BaslangicElder =0;
    }
    strcpy(elderSirasi[SonuncuElder++],toplu[i].isim);
     printf("\n%s Eklendi\n",toplu[i].isim);
      printf("\n Elderekle: %d %d\n",BaslangicElder,SonuncuElder);

      }
       else{
        printf("kuyruktaki maksimum 10 kisidir.Bu gruptan birine hizmet edilmeden ekleme.\n");
     }
}
void ChildSilme(struct degerler toplu[],int i){
int j;
  for( j=0; j<Cevirme(toplu[i].isim); j++){
        if(BaslangicChild == SonuncuChild) {
        if(servisSayisi<servisMax){
        printf("\n*****\n");
        servisSayisi++;
        outputaEkle("*****",toplu[i].yasgrup,servisSayisi);
         }
          else{
            printf("max servis ulasildi paydos.\n");
           }
           }
    else {

         if(servisSayisi<servisMax){
        servisSayisi++;
        outputaEkle(childSirasi[BaslangicChild],toplu[i].yasgrup,servisSayisi);
        printf("\n%s Cikarildi",childSirasi[BaslangicChild]);
        BaslangicChild++;
         printf(" \n childsilme: %d %d\n",BaslangicChild , SonuncuChild);
         }
         else{
            printf("max servis ulasildi paydos.\n");
           }

    }
  }

}
void AdultSilme(struct degerler toplu[],int i){
	int j;
for(j=0; j<Cevirme(toplu[i].isim); j++){
        if(BaslangicAdult == SonuncuAdult) {

         if(servisSayisi<servisMax){
        servisSayisi++;
        outputaEkle("*****",toplu[i].yasgrup,servisSayisi);
        printf("\n*****\n");
         }
         else{
            printf("max servis ulasildi paydos.\n");
           }

    }
    else {


           if(servisSayisi<servisMax){
                servisSayisi++;
    outputaEkle(adultSirasi[BaslangicAdult],toplu[i].yasgrup,servisSayisi);
        printf("\n%s Cikarildi",adultSirasi[BaslangicAdult]);
        BaslangicAdult++;
         printf(" \n Adultsilme: %d %d\n",BaslangicAdult , SonuncuAdult);
           }
           else{
            printf("max servis ulasildi paydos.\n");
           }
    }

  }

  }


void ElderSilme(struct degerler toplu[],int i){
int j;
    for(j=0; j<Cevirme(toplu[i].isim); j++){
            if(BaslangicElder == SonuncuElder) {
                 if(servisSayisi<servisMax){
                        servisSayisi++;
                outputaEkle("*****",toplu[i].yasgrup,servisSayisi);
                printf("\n*****\n");
                 }
                 else{
            printf("\n max servis ulasildi paydos.\n");
           }
    }
    else {

         if(servisSayisi<servisMax){
        servisSayisi++;
        outputaEkle(elderSirasi[BaslangicElder],toplu[i].yasgrup,servisSayisi);
        printf("\n%s Cikarildi",elderSirasi[BaslangicElder]);
        BaslangicElder++;
         printf(" \n Eldersil: %d %d\n",BaslangicElder , SonuncuElder);
         }
         else{
            printf("max servis ulasildi paydos.\n");
           }

    }
    }
  }



int kelimeHesapla() {
    int kelime = 0;

    if((dosya =fopen("input.txt","a+"))!= NULL) {

    while(!feof(dosya)) {
        char ch[20];
        if(fscanf(dosya,"%s",&ch)!= NULL) {
            kelime++;
        }}
     if(feof(dosya)) {
        fputs("\n",dosya);
        }


    //printf("%d",kelime);

    }
    else{
        printf("dosyaya ulasilamadi");
    }
        return (kelime-1)/3;
        fclose(dosya);
}
int Cevirme(char *str){

    return atoi(str);
}
void outputaEkle(char isim[],char grup, int servisSayisi){

   // printf("\n%s Gelen isimler\n",isim);
    strcpy(outputIsim[servisSayisi],isim);
    outputkod[servisSayisi] = grup;
}
void outputYazdir(){
if((dosya =fopen("output.txt","w+"))!= NULL) {
int i;
    for(i=servisSayisi;i>0; i--){
        fprintf(dosya , "%c \t %s\n",outputkod[i], outputIsim[i]);

        printf("\t%c \t %s\n", outputkod[i], outputIsim[i]);
    }

    }
}
int main()
{

    countN = 0;
    countS = 0;

    servisSayisi=0;
    struct degerler toplu[kelimeHesapla()];
     oku(toplu);
    Ayirma(toplu);
    outputYazdir();
    printf("%d newlenen \t %d servelar", countN,countS);


    return 0;
}
